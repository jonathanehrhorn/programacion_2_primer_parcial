package primerparcial;

import java.util.Objects;

public class Flor extends Planta {
    private Temporada temporadaFlorecimiento;

    public Flor(Temporada temporadaFlorecimiento, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.temporadaFlorecimiento = temporadaFlorecimiento;
    }

    @Override
    public void podar() {
        System.out.println("Las flores no se pueden podar");
    }

    @Override
    public String toString() {
        return "Nombre: " + getNombre() + "\nUbicacion: " + getUbicacion() + 
                "\nClima: " + getClima() + "\nTemporada Florecimiento: " + 
                temporadaFlorecimiento;
    }    

    @Override
    public int hashCode() {
        return Objects.hash(getNombre(), getUbicacion());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof String str) {
            return getNombre().equals(str);
        }
        if (obj instanceof Flor f) {
            return getNombre().equals(f.getNombre()) && 
                    getUbicacion().equals(f.getUbicacion());
        }
        return false;
    }
}
