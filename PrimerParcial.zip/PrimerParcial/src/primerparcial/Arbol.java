package primerparcial;

import java.util.Objects;

public class Arbol extends Planta {
    private int alturaMaxima;

    public Arbol(int alturaMaxima, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    @Override
    public void podar() {
        System.out.println("El arbol ha sido podado");
    }

    @Override
    public String toString() {
        return "Nombre: " + getNombre() + "\nUbicacion: " + getUbicacion() + 
                "\nClima: " + getClima() + "\nAltura Maxima: " + alturaMaxima;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNombre(), getUbicacion());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof String str) {
            return getNombre().equals(str);
        }
        if (obj instanceof Arbol a) {
            return getNombre().equals(a.getNombre()) && 
                    getUbicacion().equals(a.getUbicacion());
        }
        return false;
    }
    
    
}
