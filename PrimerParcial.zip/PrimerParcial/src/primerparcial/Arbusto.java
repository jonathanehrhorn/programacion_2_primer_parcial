package primerparcial;

import java.util.Objects;

public class Arbusto extends Planta {
    private static int MIN_FOLLAJE = 1;
    private static int MAX_FOLLAJE = 10;
    private int densidadFollaje;

    public Arbusto(int densidadFollaje, String nombre, String ubicacion, String clima) {
        super(nombre, ubicacion, clima);
        validarDensidadFollaje(densidadFollaje);
        this.densidadFollaje = densidadFollaje;
    }

    private void validarDensidadFollaje(int densidadFollaje) {
        if (densidadFollaje < Arbusto.MIN_FOLLAJE || densidadFollaje > Arbusto.MAX_FOLLAJE) {
            throw new IllegalArgumentException();
        }        
    }
    
    @Override
    public void podar() {
        System.out.println("El arbusto ha sido podado");
    }

    @Override
    public String toString() {
        return "Nombre: " + getNombre() + "\nUbicacion: " + getUbicacion() + 
                "\nClima: " + getClima() + "\nDensidad Follaje: " + 
                densidadFollaje;
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNombre(), getUbicacion());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (obj instanceof String str) {
            return getNombre().equals(str);
        }
        if (obj instanceof Arbusto a) {
            return getNombre().equals(a.getNombre()) && 
                    getUbicacion().equals(a.getUbicacion());
        }
        return false;
    }
}
