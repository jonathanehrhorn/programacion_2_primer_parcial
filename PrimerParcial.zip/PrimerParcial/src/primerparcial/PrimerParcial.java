package primerparcial;

public class PrimerParcial {

    public static void main(String[] args) {
        Jardin j1 = new Jardin();
        
        Arbol a1 = new Arbol(12, "Roble", "Norte", "Primavera");
        Arbol a2 = new Arbol(12, "Roble", "Norte", "Primavera");
        Arbusto a3 = new Arbusto(8, "Arbusto", "Oeste", "Primavera");
        Flor f1 = new Flor(Temporada.VERANO, "Flor", "Sur", "Verano");
        
        j1.agregarPlanta(a1);
        // j1.agregarPlanta(a2);
        j1.agregarPlanta(a3);
        j1.agregarPlanta(f1);
        
        j1.mostrarPlantas();
    }
    
}
