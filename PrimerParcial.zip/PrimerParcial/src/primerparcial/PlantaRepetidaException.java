package primerparcial;

public class PlantaRepetidaException extends RuntimeException {
    private static final String MESSAGE = "No se puede agregar dos veces la misma planta";

    public PlantaRepetidaException() {
        super(MESSAGE);
    }        
}
