package primerparcial;

import java.util.ArrayList;
import java.util.List;

public class Jardin {
    private List<Planta> plantas = new ArrayList<>();
    
    public void agregarPlanta(Planta p) {
        if (p == null) {
            throw new NullPointerException("Error. Ha introducido un null");
        }
        if (plantas.contains(p)) {
            throw new PlantaRepetidaException();
        }
        plantas.add(p);
    }
    
    public void mostrarPlantas() {
        if (plantas.isEmpty()) {
            System.out.println("La lista esta vacia");
        }
        for (Planta p : plantas) {
            System.out.println(p.toString());
        }
    }        
}
